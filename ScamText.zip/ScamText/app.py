"""ScamText Flask server. Runs locally; user messages are never stored or logged."""
import json, pickle, re
from pathlib import Path
from flask import Flask, render_template, request, jsonify
import numpy as np
from text_utils import preprocess, detect_language

BASE = Path(__file__).parent
MAX_CHARS = 1000
app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024

with open(BASE / "models" / "vectorizer.pkl", "rb") as f:
    VEC = pickle.load(f)
with open(BASE / "models" / "scamtext_model.pkl", "rb") as f:
    CLF = pickle.load(f)
METRICS = json.loads((BASE / "results" / "metrics.json").read_text(encoding="utf-8"))
LANGS = {"auto", "Kazakh", "Russian", "English", "Chinese"}


def spam_proba(texts):
    return CLF.predict_proba(VEC.transform([preprocess(t) for t in texts]))[:, 1]


def explain(text, is_spam, top=3):
    """Leave-one-word-out: which words moved the model most toward its verdict."""
    chinese = detect_language(text) == "Chinese"
    words = [w for w in re.split(r"[，。！？；：、（）【】「」“”,.!?;:()\[\]\s]+", text) if w] if chinese else text.split()
    sep = "，" if chinese else " "
    if len(words) < 2:
        return []
    base = spam_proba([text])[0]
    variants = [sep.join(words[:i] + words[i + 1:]) for i in range(len(words))]
    shifts = base - spam_proba(variants)          # >0: word pushes toward Spam
    shifts = shifts if is_spam else -shifts       # orient toward predicted class
    order = np.argsort(-shifts)[:top]
    return [words[i].strip(".,!?:;()[]\"'") for i in order if shifts[i] > 0.005]


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/analyzer")
def analyzer():
    return render_template("analyzer.html", max_chars=MAX_CHARS)


@app.route("/how-it-works")
def how_it_works():
    return render_template("how_it_works.html")


@app.route("/performance")
def performance():
    return render_template("performance.html", m=METRICS)


@app.route("/about")
def about():
    return render_template("about.html", m=METRICS)


@app.route("/api/analyze", methods=["POST"])
def api_analyze():
    data = request.get_json(silent=True) or {}
    text = data.get("text")
    lang = data.get("language", "auto")
    if not isinstance(text, str) or not text.strip():
        return jsonify(error="Мәтін бос. Тексеру үшін хабарлама енгізіңіз."), 400
    text = text.strip()
    if len(text) > MAX_CHARS:
        return jsonify(error=f"Мәтін тым ұзын. Ең көбі {MAX_CHARS} таңба."), 400
    if lang not in LANGS:
        return jsonify(error="Белгісіз тіл таңдалды."), 400
    try:
        p = float(spam_proba([text])[0])
        is_spam = p >= 0.5
        detected = detect_language(text)
        return jsonify(
            label="Spam" if is_spam else "Ham",
            language=detected if lang == "auto" else lang,
            language_detected=detected,
            confidence=round(p if is_spam else 1 - p, 4),
            spam_probability=round(p, 4),
            suspicious_words=explain(text, is_spam),
        )
    except Exception:
        return jsonify(error="Талдау кезінде қате орын алды. Қайталап көріңіз."), 500


@app.errorhandler(413)
def too_large(_):
    return jsonify(error="Сұраныс тым үлкен."), 413


@app.errorhandler(404)
def not_found(_):
    return render_template("index.html"), 404


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
